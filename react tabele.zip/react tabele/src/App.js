
import './App.css';
import Users from './components/users';
import UserDetail from './components/userDetail';
import Posts from './components/posts';
import Home from './components/home';
import {Route, Routes, Navigate, Link,BrowserRouter,useParams} from 'react-router-dom';
import { useState } from 'react';

function App() {

  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
        <Route path='/posts' element={<Posts/>}/>
        <Route path='/user-details/:username' element={<UserDetail />}/>
        <Route path='/users' element={<Users/>}/>
        <Route path='*' element={<Home/>}/>
      </Routes>
      </BrowserRouter>
     
    </div>
  );
}

export default App;
