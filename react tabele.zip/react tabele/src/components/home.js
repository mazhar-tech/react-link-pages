import { Link } from "react-router-dom";

const Home = () => {
    
    return(
<div>
    <h1>This is a homepage</h1>
    <Link className="btn btn-primary" to={`/users`}>Go to User List</Link>
</div>
    )
}

export default Home;