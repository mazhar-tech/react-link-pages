import { useState, useEffect } from "react"
import { useParams } from "react-router-dom";
const UserDetail = () => {
    
    const {username} = useParams();
    const [data,setData]= useState({})
    useEffect(()=>{
        fetch('https://jsonplaceholder.typicode.com/todos/1')
  .then(response => response.json())
  .then(json => setData(json))
    },[])

    return(
<div>{`now showing ${username}`}</div>
    )
}

export default UserDetail;