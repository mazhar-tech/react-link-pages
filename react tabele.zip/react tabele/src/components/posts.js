import { useState, useEffect } from "react";

const Posts = () => {
    const [data,setData]= useState([])
    useEffect(()=>{
        fetch('https://jsonplaceholder.typicode.com/todos/1')
  .then(response => response.json())
  .then(json => setData(json))
    },[])

    
    return(
<div></div>
    )
}

export default Posts;