import { useState, useEffect } from "react";
import { Link } from "react-router-dom";


const Users = () => {
  const [users, setUsers] = useState([]);


  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((response) => response.json())
      .then((json) => setUsers(json));
  }, []);

  console.log(users)
  return (
    <div >
<h1>This is Users Page</h1>
{users.map(user=>(
      <p><Link className="btn btn-primary" to={`/user-details/${user.name}`}>
        {user.name}
      </Link></p>))}
    </div>
  );
};

export default Users;
